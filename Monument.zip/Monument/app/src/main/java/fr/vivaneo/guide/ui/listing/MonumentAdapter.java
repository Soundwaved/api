package fr.vivaneo.guide.ui.listing;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import fr.vivaneo.guide.R;
import fr.vivaneo.guide.model.Monument;

public class MonumentAdapter extends ArrayAdapter<Monument> {
    private int resId;

    public MonumentAdapter(@NonNull Context context, int resource, @NonNull List<Monument> objects) {
        super(context, resource, objects);

        resId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //déclaration
        ViewHolder myViewHolder;

        if (convertView == null) {
            Log.e("convertView", "is null");
            // affichage de layout item_restaurant
            convertView = LayoutInflater.from(getContext()).inflate(resId, null);// R.layout.item_restaurant

            myViewHolder = new ViewHolder();//instance

            // recupération des vues
            myViewHolder.textViewTitle = convertView.findViewById(R.id.textViewTitle);
            myViewHolder.textViewCategory = convertView.findViewById(R.id.textViewCategory);

            //enregistrement de l'objet myViewHolder dans le convertView
            convertView.setTag(myViewHolder);
        }else {
            Log.e("convertView", "inNOT null");

            //recupération de l'objet myViewHolder
            myViewHolder = (ViewHolder) convertView.getTag();
        }

        // objet Restaurant
        Monument item = getItem(position);

        //affichage des informations
        myViewHolder.textViewTitle.setText(item.getName());
        myViewHolder.textViewCategory.setText(item.getCategory());

        return convertView;
    }

    class ViewHolder{
        TextView textViewTitle, textViewCategory;
    }

}
