package fr.vivaneo.guide.ui.main;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

import androidx.appcompat.app.AppCompatActivity;
import fr.vivaneo.guide.R;
import fr.vivaneo.guide.ui.AppActivity;
import fr.vivaneo.guide.ui.home.HomeActivity;

public class MainActivity extends AppActivity {

    private Timer myTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myTimer = new Timer();
        myTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                // TODO : lancement de l'écran HomeActivity
                //utilisation d'un Intent explicite
                Intent myIntent = new Intent(MainActivity.this, HomeActivity.class );//  Intent gerer les composant android
                startActivity(myIntent);
                finish();

            }
        }, 2000);
    }
}