package fr.vivaneo.guide.ui.home;

import androidx.appcompat.app.AppCompatActivity;
import fr.vivaneo.guide.R;
import fr.vivaneo.guide.ui.AppActivity;
import fr.vivaneo.guide.ui.listing.ListingActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HomeActivity extends AppActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void showMonument(View view) {
        Intent intentMonument = new Intent(HomeActivity.this, ListingActivity.class);

        //TODO : envoyer en parametre
        intentMonument.putExtra("isMonument",true);

        startActivity(intentMonument);
    }

    public void showMusee(View view) {
        Intent intentMusee = new Intent(HomeActivity.this, ListingActivity.class);

        //TODO : envoyer en parametre
        intentMusee.putExtra("isMonument",false);

        startActivity(intentMusee);
    }
}