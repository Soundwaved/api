package fr.vivaneo.guide.ui.listing;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import fr.vivaneo.guide.ui.AppActivity;
import fr.vivaneo.guide.ui.details.DetailsActivity;
import fr.vivaneo.guide.R;
import fr.vivaneo.guide.model.Monument;

public class ListingActivity extends AppActivity {
    // déclarations
    private TextView textViewTitle;
    private ListView listViewData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listing);
        // récupération des vues
        textViewTitle = findViewById(R.id.textViewTitle);
        listViewData = findViewById(R.id.listViewData);
        if(getIntent().getExtras() != null) {
            boolean isMonument = getIntent().getExtras().getBoolean("isMonument");
            if(isMonument) {
                textViewTitle.setText("Les Monuments");
                List<Monument> monumentList = new ArrayList<>();
                monumentList.add(new Monument(
                                "Tour Eiffel",
                                "Monument",
                                "info@Eiffel.fr",
                                "0102030405",
                                "http://www.TourEiffel.fr",
                                "https://storage.lebonguide.com/crop-1600x700/3/83/8B9B7F45-252B-46D1-921B-2EF5A8A4133B.png"
                         )
                );
                monumentList.add(new Monument(
                                "Notre Dame",
                                "Monument",
                                "info@notre_dame_de_paris.fr",
                                "0102030405",
                                "http://www.notredame.fr",
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThNU_nI6rgFRNACMguTry0LWTSXivWWX_DHw&usqp=CAU"
                        )
                );
                monumentList.add(new Monument(
                                "Arc de Triomphe",
                                "Monument",
                                "info@arcdetriommphe.fr",
                                "0102030405",
                                "http://www.paris-arc-de-triomphe.fr/",
                                "https://vivreparis.fr/wp-content/uploads/2019/07/arc-de-triomphe-paris-elephant.jpg"
                        )
                );
                monumentList.add(new Monument(
                                "Sacrée Coeur",
                                "Monument",
                                "info@sacree-coeur.fr",
                                "0102030405",
                                "http://www.sacre-coeur-montmartre.com/",
                                "https://www.grandearche.com/wp-content/uploads/2018/08/La-Basilique-du-sacr%C3%A9-coeur-Montmartre-et-lesplanade.jpg"
                        )
                );
                monumentList.add(new Monument(
                                "Tour Saint-Jacques",
                                "Monument",
                                "info@TourSaint-Jacques.fr",
                                "0102030405",
                                "https://www.parisinfo.com/musee-monument-paris/71267/Tour-Saint-Jacques",
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTr9TX_Pb5Rc-QvNi2J7cBNyKDNLrFpF4njjw&usqp=CAU"
                        )
                );



                listViewData.setAdapter(
                        new MonumentAdapter(
                                ListingActivity.this,
                                R.layout.item_monument,
                                monumentList
                        )
                );
                listViewData.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        Monument item =  monumentList.get(position);

                        // Intent
                        Intent intent = new Intent(ListingActivity.this, DetailsActivity.class);

                        //passage de plusieurs parametre
                        //intend.putExtra("name",item.getName());
                        //intent.putExtra("category", item.getCategory());

                        //passage de l'objet
                        intent.putExtra("objet",  item);

                        startActivity(intent);
                    }
                });

            } else {
                textViewTitle.setText("Les Musée");
                List<Monument> monumentList = new ArrayList<>();
                monumentList.add(new Monument(
                                "Muséé du Louvre",
                                "Musée",
                                "info@Louvre.fr",
                                "0102030405",
                                "https://www.louvre.fr/",
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0dWc6Ons84lftLJpDbQnh1Qg7yeBhg9a3BQ&usqp=CAU"
                        )
                );
                monumentList.add(new Monument(
                                "Beaux-ART",
                                "Musée",
                                "info@beauART.fr",
                                "0102230445",
                                "https://www.parisinfo.com/visiter-a-paris/musees/les-musees-les-plus-visites",
                                "https://www.normandie-tourisme.fr/wp-content/uploads/wpetourisme/Musee-des-Beaux-Arts---Rouen-----Musees-de-la-ville-de-Rouen--Agence-La-Belle-Vie--2--3-800x600.jpg"
                        )
                );
                monumentList.add(new Monument(
                                "Arc de Triomphe",
                                "Monument",
                                "info@arcdetriommphe.fr",
                                "0102030405",
                                "http://www.paris-arc-de-triomphe.fr/",
                                "https://vivreparis.fr/wp-content/uploads/2019/07/arc-de-triomphe-paris-elephant.jpg"
                        )
                );


                listViewData.setAdapter(
                        new MonumentAdapter(
                                ListingActivity.this,
                                R.layout.item_monument,
                                monumentList
                        )
                );
                listViewData.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        Monument item =  monumentList.get(position);

                        // Intent
                        Intent intent = new Intent(ListingActivity.this, DetailsActivity.class);

                        //passage de plusieurs parametre
                        //intend.putExtra("name",item.getName());
                        //intent.putExtra("category", item.getCategory());

                        //passage de l'objet
                        intent.putExtra("objet",  item);

                        startActivity(intent);
                    }
                });

            }
        }
    }
}